# Output

Final tables and generated results. Figures are in `../figures/`.

## Key results (from the executed notebook)

| Result | Value |
|---|---|
| Films after cleaning | 87,286 (training 69,828, test 17,458) |
| Mean rating: non-US / US only / US co-production | 3.32 / 3.16 / 3.12 |
| US-involved effect, controlling for genre, year, runtime | -0.160 stars (95% CI -0.165 to -0.154) |
| Best model (gradient boosting) CV RMSE | 0.315 (baseline 0.419) |
| Test RMSE / R² | 0.315 / 0.441 (baseline test RMSE 0.421) |
| Rating tiers: test accuracy / macro-F1 | 0.612 / 0.609 (baseline 0.336 / 0.168) |
| Cast features: US coefficient without / with | -0.170 / -0.166 |

| Model (genre only) | CV RMSE | CV R² |
|---|---|---|
| Baseline (mean) | 0.419 | 0.000 |
| Ridge | 0.350 | 0.301 |
| Lasso | 0.350 | 0.301 |
| Decision tree | 0.338 | 0.351 |
| Random forest | 0.318 | 0.423 |
| Gradient boosting | 0.315 | 0.433 |
