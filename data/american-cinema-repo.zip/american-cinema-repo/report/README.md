# Report

Add the final written report here as `report.pdf` (Google Docs: File → Download → PDF). A plain-text copy of the short version is in `report.md`.
