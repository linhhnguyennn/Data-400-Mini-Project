# American Cinema in a Global Context: Comparing Audience Ratings of American and Non-American Films

[Your name] · Data 400 Mini-Project · [Date]

## Research Question

How do Letterboxd average ratings of American films compare with those of films made outside the United States, and does the difference vary by genre?

## Disciplinary Motivation

This project connects my Data Analytics major with American Studies and my Film Studies minor. Courses such as Introduction to American Studies, Black Horror, and Fashion & Body Politics taught me to treat film as cultural production: a medium through which a society represents its values and identities, and also an industry. I use data to ask whether American origin shows up as a measurable difference in how audiences respond. I am not trying to decide which cinema is better.

## Stakeholders

The findings are relevant to students and scholars of American Studies and Film Studies, to data analysts applying quantitative methods to cultural data, and to film programmers, distributors, and critics interested in how audience ratings differ by national origin and genre.

## Data

I used the Letterboxd (Movies Dataset) on Kaggle, joining the movies, countries, genres, themes, and actors files by film ID. Of 941,597 films, 90,999 had an average rating, and 87,286 remained after requiring a valid year (1900 to 2025) and a listed country. A film is "US only" (35%) if the United States is its only listed country, a "US co-production" (11%) if the United States appears with other countries, and "non-US" (54%) otherwise. The unit of observation is one film, and the target is its average rating.

## Analysis

Before any exploration, I split the films 80/20 into training and test sets, stratified by origin and decade. Using the training set only, I compared ratings by origin, decade, and genre. I then built a single scikit-learn pipeline for imputation, encoding, and scaling, and compared a mean baseline, Ridge, Lasso, a decision tree, a random forest, and gradient boosting using 5-fold cross-validation and RMSE. I tuned the best model and evaluated it once on the test set. A multiple regression with genre-by-origin interactions estimated the US effect while controlling for year, runtime, and genre. I checked robustness with Low/Medium/High rating tiers, alternative co-production rules, and cast features.

## Findings

Non-US films average 3.32 stars, US-only films 3.16, and US co-productions 3.12. After controlling for genre, year, and runtime, US-involved films are rated 0.16 stars lower than non-US films (95% CI -0.165 to -0.154). US-only films rate lower in all 19 genres, with the widest gap in Family and Horror and a reversal in Documentary.

The estimate holds under every co-production classification (-0.151 to -0.164) and in Lasso. In the rating tiers, 41% of US-only films but 25% of non-US films fall in the Low tier. Cast size and prolific actors do not explain the gap, since the coefficient moves only from -0.170 to -0.166.

Gradient boosting had the lowest cross-validated RMSE (0.315). On the test set its RMSE was 0.315 (R² = 0.44), compared with 0.421 for the baseline. Themes added little, and theme data is missing for most non-US films, so the main model uses genres only.

The widest gaps are in studio-style genres such as Family, Action, and Horror, and non-US ratings are more consistent. This fits the idea that ratings reflect how films are produced, circulated, and filtered before reaching Letterboxd's audience.

## Limitations

The dataset has no rating counts, so some averages are noisy. Letterboxd users are a self-selected audience, and the results show association, not cause. "American" is defined by listed production countries, not by a film's story or funding, and all non-US countries are grouped together. Theme data is incomplete, the cast features are crude proxies, and the rating-tier cutoffs are arbitrary.

## Conclusion

Across 87,286 Letterboxd films, American-involved films are rated about 0.16 stars lower than non-US films after controlling for genre, year, and runtime, and the pattern is consistent across models and classifications. The gap is largest in studio-style genres and reverses in documentary. The best model predicts ratings with a test RMSE of 0.315, compared with 0.421 for the baseline. For American Studies, the pattern points to how films are produced, circulated, and rated more than to anything inherent in American culture. Future work should add rating counts, compare individual countries, and analyze film descriptions for social themes.
