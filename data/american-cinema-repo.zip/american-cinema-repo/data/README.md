# Data

**This repository does not contain the data files.** The full dataset is large (the cast file alone has about 5.8 million rows) and GitHub rejects files over 100 MB. Instead, this folder explains how to get the exact files used, and `code/download_data.py` downloads them for you.

## Source

**Letterboxd (Movies Dataset)** by gsimonx37 on Kaggle: <https://www.kaggle.com/datasets/gsimonx37/letterboxd>

- **Version used:** 2 (confirm on the dataset page, under the Versions tab)
- **License / terms:** [copy the License field from the Kaggle page here]
- **Citation:** gsimonx37. *Letterboxd (Movies Dataset)*. Kaggle. <https://www.kaggle.com/datasets/gsimonx37/letterboxd>

## Files used

| File | Rows | Columns | Columns used in this project | Purpose |
|---|---|---|---|---|
| `movies.csv` | 941,597 | `id`, `name`, `date`, `tagline`, `description`, `minute`, `rating` | `id`, `date`, `minute`, `rating` | One row per film; `rating` (average rating) is the target |
| `countries.csv` | 693,476 | `id`, `country` | both | Production origin (US only, US co-production, non-US) |
| `genres.csv` | 1,046,849 | `id`, `genre` | both | 19 genre indicators |
| `themes.csv` | 125,641 | `id`, `theme` | both | Optional theme features |
| `actors.csv` | 5,798,450 | `id`, `name`, `role` | `id`, `name` | Cast size and prolific-actor features |

All files are linked by the film `id`. The other files in the Kaggle dataset (crew, languages, studios, posters, releases) are not used.

## How to get the data

### Option 1: run the script (recommended)

```bash
pip install kagglehub pandas
python code/download_data.py
```

This saves the five CSV files into `data/raw/` and checks their row counts against the table above. The `data/raw/` folder is ignored by git.

### Option 2: run the notebook

The first cells of `notebooks/DATA_400_Mini_Project.ipynb` download the same files automatically, so you can skip the script if you only want to run the analysis.

### Option 3: download manually

1. Open the dataset page (link above) and sign in to Kaggle.
2. Click **Download** and unzip the archive.
3. Copy `movies.csv`, `countries.csv`, `genres.csv`, `themes.csv`, and `actors.csv` into `data/raw/`.

## Check that you have the right data

After downloading, the row counts should match the table above, for example 941,597 rows in `movies.csv` and 87,286 films remaining after the notebook's cleaning step. A different count usually means a different dataset version.

## Troubleshooting

- **Checksum or corrupted-download error:** delete the cache and rerun: `rm -rf ~/.cache/kagglehub/datasets/gsimonx37/letterboxd` (the script already forces a fresh download).
- **Authentication prompt:** public datasets usually download without a login. If asked, run `python -c "import kagglehub; kagglehub.login()"`, or set the `KAGGLE_USERNAME` and `KAGGLE_KEY` environment variables from a Kaggle API token (Settings, then API, then Create New Token). **Never commit `kaggle.json`.**
- **Slow download:** the cast file is the largest. Use Google Colab for a faster connection.
