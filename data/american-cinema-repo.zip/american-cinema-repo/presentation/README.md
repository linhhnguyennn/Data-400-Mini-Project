# Presentation

`slides.html` is the slide deck. Open it in a browser and use the arrow keys. Add an exported PDF or PowerPoint version here if your instructor requires one.
