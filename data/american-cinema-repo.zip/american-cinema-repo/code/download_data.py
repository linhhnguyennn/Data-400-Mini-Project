"""Download the Letterboxd files used in this project into data/raw/.

Usage:   python code/download_data.py
Requires: pip install kagglehub pandas

Dataset: https://www.kaggle.com/datasets/gsimonx37/letterboxd
"""
import shutil
from pathlib import Path

import kagglehub
import pandas as pd

DATASET = "gsimonx37/letterboxd"
VERSION = 2  # version used for the analysis; confirm on the dataset's Versions tab

# Expected row counts for the version used (from the executed notebook)
EXPECTED_ROWS = {
    "movies.csv": 941_597,
    "countries.csv": 693_476,
    "genres.csv": 1_046_849,
    "themes.csv": 125_641,
    "actors.csv": 5_798_450,
}

OUT = Path(__file__).resolve().parent.parent / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)


def fetch(name: str) -> str:
    """Download one file, pinned to VERSION when possible. force_download avoids half-downloaded caches."""
    try:
        return kagglehub.dataset_download(f"{DATASET}/versions/{VERSION}", path=name, force_download=True)
    except Exception as err:  # fall back to the latest version
        print(f"Could not get version {VERSION} of {name} ({err}); using the latest version instead.")
        return kagglehub.dataset_download(DATASET, path=name, force_download=True)


for name, expected in EXPECTED_ROWS.items():
    dest = OUT / name
    shutil.copy(fetch(name), dest)
    rows = len(pd.read_csv(dest, usecols=[0]))
    status = "OK" if rows == expected else f"WARNING: expected {expected:,}"
    print(f"saved {dest}  ({rows:,} rows)  {status}")
