# American Cinema in a Global Context

**Do American films get rated differently from films made elsewhere?** A Data 400 mini-project comparing Letterboxd average ratings of American and non-American films.

Author: [Your name] · Course: Data 400 · [Institution] · [Date]

## Project question

> How do Letterboxd average ratings of American films compare with those of films made outside the United States, and does the difference vary by genre?

This project connects my Data Analytics major with American Studies and Film Studies by treating film as cultural production. It follows the Data 400 workflow: frame the problem, get the data, split before exploring, explore and visualize, prepare data in a pipeline, compare models with cross-validation, tune the best model, evaluate once on a held-out test set, and report limitations.

### Key findings

- US-involved films are rated about **0.16 stars lower** than non-US films (95% CI -0.165 to -0.154) after controlling for genre, release year, and runtime.
- The gap appears in all 19 genres, is largest in Family and Horror, and reverses in Documentary.
- The result holds under every co-production rule, in Lasso, and in Low/Medium/High rating-tier models. Cast features do not explain it.
- The best model (gradient boosting) has a **test RMSE of 0.315** vs. 0.421 for a mean baseline (R² = 0.44).
- This is an association shaped by who rates which films on Letterboxd, not evidence that American films are worse.

## Data source

**Letterboxd (Movies Dataset)** on Kaggle: <https://www.kaggle.com/datasets/gsimonx37/letterboxd>. Files used: `movies.csv`, `countries.csv`, `genres.csv`, `themes.csv`, `actors.csv`. The data is **not included** in this repository because it is large. See [`data/README.md`](data/README.md) for details and download instructions, and check the dataset page for license terms.

**Origin rule:** a film is *US only* if "USA" is its only listed country, a *US co-production* if "USA" appears with other countries, and *non-US* otherwise.

## Repository structure

```
.
├── README.md                  # this file
├── requirements.txt           # Python packages
├── .gitignore                 # keeps data and credentials out of git
├── data/
│   └── README.md              # data source, files used, how to download (no data files committed)
├── code/
│   └── download_data.py       # downloads the five CSV files into data/raw/
├── notebooks/
│   └── DATA_400_Mini_Project.ipynb   # full analysis: cleaning, exploration, modeling, results
├── figures/                   # 11 figures exported from the notebook
├── output/
│   └── README.md              # key result tables
├── report/
│   ├── README.md
│   └── report.md              # written report (add report.pdf)
└── presentation/
    ├── README.md
    └── slides.html            # slide deck
```

### What the notebook contains

| Section | What it does |
|---|---|
| 1. Get the data | Downloads the files, checks heads, missing values, and country spellings |
| 2. Build one row per film | Cleans years, applies the origin rule, builds genre indicators |
| 3. Split | 80/20 train/test split stratified by origin and decade; themes chosen from training data only |
| 4. Exploratory analysis | Ratings by origin, decade, and genre; genre and theme frequencies; theme and cast coverage (training set only) |
| 5. Models | One pipeline; baseline, Ridge, Lasso, decision tree, random forest, and gradient boosting compared with 5-fold cross-validation |
| 6. Tuning | Randomized hyperparameter search |
| 7. Test evaluation | One-time test-set evaluation with permutation importance |
| 8. US effect | OLS with controls, genre interactions, and a co-production robustness check |
| 9. Rating tiers | Low/Medium/High classification with training-set tercile cutoffs |
| 10. Casting | Does adding cast features change the US effect or improve prediction? |

## Requirements

- Python 3.10 or newer (developed in Google Colab, Python 3.13)
- Jupyter or Google Colab (the notebook uses `display()`)
- Packages in `requirements.txt`: `pandas`, `numpy`, `scikit-learn`, `statsmodels`, `matplotlib`, `seaborn`, `kagglehub`, `notebook`
- Internet access to download the dataset from Kaggle

## How to reproduce the analysis

### In Google Colab (recommended)

1. Open <https://colab.research.google.com>, choose **File → Open notebook → GitHub**, and open `notebooks/DATA_400_Mini_Project.ipynb` (or upload the file).
2. Optional: **Runtime → Change runtime type → High-RAM** if memory runs out.
3. Run the cells **in order, top to bottom**. The first cell installs packages, and the data cell downloads the five files (rerun it if a download is corrupted).
4. Confirm the notebook runs cleanly with **Runtime → Restart session and run all**.

### Locally

```bash
git clone https://github.com/[your-username]/[your-repo].git
cd [your-repo]
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python code/download_data.py      # optional: saves the CSVs to data/raw/
jupyter notebook notebooks/DATA_400_Mini_Project.ipynb
```

If you run locally, delete the `!pip install` line in the first cell and the Colab-specific cache-clearing line (`!rm -rf /root/.cache/...`) in the data cell.

If Kaggle asks for credentials, create a token (Kaggle **Settings → API → Create New Token**) and supply it through environment variables or Colab Secrets. **Never commit `kaggle.json`.**

## Reproducibility and integrity notes

- All random operations use `random_state=42`.
- The train/test split happens before exploration. Exploration, model comparison, and tuning use the training set only.
- Preprocessing lives in one scikit-learn pipeline fit on training data only.
- The test set is used once per task (regression, tier classification, cast comparison).
- Watches, likes, and similar engagement measures are excluded to avoid target leakage.

## Limitations

No rating counts, so some averages are noisy; Letterboxd users are a self-selected audience; results show association, not cause; "American" is defined by production country and all non-US countries are grouped together; theme data is mostly missing for non-US films (about 14% coverage vs. 39% for US-only films), so the main model uses genres only; cast features are crude proxies; rating-tier cutoffs are arbitrary.

## Project log

Update this table as the project progresses.

| Date | Update |
|---|---|
| [date] | Proposal and question narrowed |
| [date] | Data downloaded, cleaned, and split |
| [date] | Exploratory analysis complete |
| [date] | Models compared and tuned; test set evaluated |
| [date] | Rating tiers and cast extensions added |
| [date] | Report and presentation finalized |

## Acknowledgments

Dataset: Letterboxd (Movies Dataset) on Kaggle, <https://www.kaggle.com/datasets/gsimonx37/letterboxd>.
